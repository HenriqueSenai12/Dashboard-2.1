// (mantive todo o conteúdo pré-existente e apenas adicionei a função de exportação/print abaixo)
// Variáveis globais
let csvData = []
let filteredData = []
let lineChart = null
let areaChart = null
let columnFilters = {}
const visibleLineSeries = {}
const visibleAreaSeries = {}

// URL padrão do CSV
const DEFAULT_CSV_URL =
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/export-UROBAzIQBbQHSapelzqEaHbLck4Fdf.csv"

// Carregar dados padrão ao iniciar
window.addEventListener("DOMContentLoaded", () => {
  loadDefaultCSV()
  setupFileInput()
})

// Configurar input de arquivo
function setupFileInput() {
  const fileInput = document.getElementById("csvFileInput")
  fileInput.addEventListener("change", handleFileSelect)
}

// Carregar CSV padrão
async function loadDefaultCSV() {
  showLoading(true)
  try {
    const response = await fetch(DEFAULT_CSV_URL)
    const csvText = await response.text()
    parseAndDisplayCSV(csvText)
  } catch (error) {
    console.error("Erro ao carregar CSV padrão:", error)
    alert("Erro ao carregar o arquivo CSV padrão. Por favor, importe um arquivo manualmente.")
  } finally {
    showLoading(false)
  }
}

// Manipular seleção de arquivo
function handleFileSelect(event) {
  const file = event.target.files[0]
  if (file) {
    showLoading(true)
    const reader = new FileReader()
    reader.onload = (e) => {
      parseAndDisplayCSV(e.target.result)
      showLoading(false)
    }
    reader.onerror = () => {
      alert("Erro ao ler o arquivo.")
      showLoading(false)
    }
    reader.readAsText(file)
  }
}

// Parsear e exibir CSV
function parseAndDisplayCSV(csvText) {
  const lines = csvText.trim().split("\n")
  const headers = lines[0].split(",").map((h) => h.trim())

  csvData = []
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(",").map((v) => v.trim())
    const row = {}
    headers.forEach((header, index) => {
      row[header] = values[index]
    })
    csvData.push(row)
  }

  filteredData = [...csvData]
  columnFilters = {}

  createColumnFilters(headers)
  createSeriesControls(headers)
  updateStatistics()
  generateDynamicStats(headers)
  updateCharts()
  updateTable(headers)
}

function createColumnFilters(headers) {
  const filtersContainer = document.getElementById("filtersContainer")
  filtersContainer.innerHTML = ""

  headers.forEach((header) => {
    const filterGroup = document.createElement("div")
    filterGroup.className = "filter-group"

    const label = document.createElement("label")
    label.innerHTML = `<span class="filter-badge">${header}</span>`

    // Verificar se a coluna é numérica
    const isNumeric = csvData.every((row) => !isNaN(row[header]) && row[header] !== "")

    if (isNumeric) {
      // Filtro numérico com range
      const values = csvData.map((row) => Number.parseFloat(row[header])).filter((v) => !isNaN(v))
      const min = Math.min(...values)
      const max = Math.max(...values)

      const rangeContainer = document.createElement("div")
      rangeContainer.className = "range-inputs"

      const minWrapper = document.createElement("div")
      minWrapper.className = "input-wrapper"
      const minLabel = document.createElement("label")
      minLabel.textContent = "Mínimo:"
      minLabel.className = "input-label"
      const minInput = document.createElement("input")
      minInput.type = "number"
      minInput.placeholder = `${min.toFixed(2)}`
      minInput.id = `filter-${header}-min`
      minInput.step = "any"
      minInput.className = "filter-input"
      minWrapper.appendChild(minLabel)
      minWrapper.appendChild(minInput)

      const maxWrapper = document.createElement("div")
      maxWrapper.className = "input-wrapper"
      const maxLabel = document.createElement("label")
      maxLabel.textContent = "Máximo:"
      maxLabel.className = "input-label"
      const maxInput = document.createElement("input")
      maxInput.type = "number"
      maxInput.placeholder = `${max.toFixed(2)}`
      maxInput.id = `filter-${header}-max`
      maxInput.step = "any"
      maxInput.className = "filter-input"
      maxWrapper.appendChild(maxLabel)
      maxWrapper.appendChild(maxInput)

      rangeContainer.appendChild(minWrapper)
      rangeContainer.appendChild(maxWrapper)

      filterGroup.appendChild(label)
      filterGroup.appendChild(rangeContainer)
    } else {
      // Filtro de seleção para valores únicos
      const uniqueValues = [...new Set(csvData.map((row) => row[header]))].filter((v) => v !== "")

      const select = document.createElement("select")
      select.id = `filter-${header}`
      select.className = "filter-select"

      const defaultOption = document.createElement("option")
      defaultOption.value = ""
      defaultOption.textContent = "Todos"
      select.appendChild(defaultOption)

      uniqueValues.sort().forEach((value) => {
        const option = document.createElement("option")
        option.value = value
        option.textContent = value
        select.appendChild(option)
      })

      filterGroup.appendChild(label)
      filterGroup.appendChild(select)
    }

    filtersContainer.appendChild(filterGroup)
  })
}

function createSeriesControls(headers) {
  const lineControls = document.getElementById("lineSeriesControls")
  const areaControls = document.getElementById("areaSeriesControls")

  lineControls.innerHTML = ""
  areaControls.innerHTML = ""

  // Filtrar apenas colunas numéricas
  const numericColumns = headers.filter((header) => {
    return csvData.every((row) => !isNaN(row[header]) && row[header] !== "")
  })

  // Inicializar todas as séries como visíveis
  numericColumns.forEach((column) => {
    visibleLineSeries[column] = true
    visibleAreaSeries[column] = true
  })

  // Criar checkboxes para gráfico de linha
  numericColumns.forEach((column) => {
    const label = document.createElement("label")
    label.className = "series-checkbox"

    const checkbox = document.createElement("input")
    checkbox.type = "checkbox"
    checkbox.checked = true
    checkbox.id = `line-series-${column}`
    checkbox.addEventListener("change", (e) => {
      visibleLineSeries[column] = e.target.checked
      updateCharts()
    })

    const span = document.createElement("span")
    span.textContent = column

    label.appendChild(checkbox)
    label.appendChild(span)
    lineControls.appendChild(label)
  })

  // Criar checkboxes para gráfico de área
  numericColumns.forEach((column) => {
    const label = document.createElement("label")
    label.className = "series-checkbox"

    const checkbox = document.createElement("input")
    checkbox.type = "checkbox"
    checkbox.checked = true
    checkbox.id = `area-series-${column}`
    checkbox.addEventListener("change", (e) => {
      visibleAreaSeries[column] = e.target.checked
      updateCharts()
    })

    const span = document.createElement("span")
    span.textContent = column

    label.appendChild(checkbox)
    label.appendChild(span)
    areaControls.appendChild(label)
  })
}

function applyFilters() {
  const headers = Object.keys(csvData[0])

  console.log("[v0] Aplicando filtros...")

  filteredData = csvData.filter((row) => {
    return headers.every((header) => {
      const isNumeric = !isNaN(row[header]) && row[header] !== ""

      if (isNumeric) {
        const minInput = document.getElementById(`filter-${header}-min`)
        const maxInput = document.getElementById(`filter-${header}-max`)

        if (minInput && maxInput) {
          const value = Number.parseFloat(row[header])
          const min = minInput.value ? Number.parseFloat(minInput.value) : Number.NEGATIVE_INFINITY
          const max = maxInput.value ? Number.parseFloat(maxInput.value) : Number.POSITIVE_INFINITY

          console.log(`[v0] Filtro ${header}: valor=${value}, min=${min}, max=${max}`)

          return value >= min && value <= max
        }
      } else {
        const select = document.getElementById(`filter-${header}`)
        if (select && select.value) {
          console.log(`[v0] Filtro ${header}: selecionado=${select.value}, valor=${row[header]}`)
          return row[header] === select.value
        }
      }

      return true
    })
  })

  console.log(`[v0] Dados filtrados: ${filteredData.length} de ${csvData.length} registros`)

  updateStatistics()
  generateDynamicStats(Object.keys(csvData[0]))
  updateCharts()
  updateTable(Object.keys(csvData[0]))

  // Mostrar mensagem de sucesso
  showFilterMessage(`Filtros aplicados! ${filteredData.length} registros encontrados.`)
}

function clearFilters() {
  const headers = Object.keys(csvData[0])

  headers.forEach((header) => {
    const select = document.getElementById(`filter-${header}`)
    if (select) {
      select.value = ""
    }

    const minInput = document.getElementById(`filter-${header}-min`)
    const maxInput = document.getElementById(`filter-${header}-max`)
    if (minInput) minInput.value = ""
    if (maxInput) maxInput.value = ""
  })

  filteredData = [...csvData]
  updateStatistics()
  generateDynamicStats(headers)
  updateCharts()
  updateTable(headers)

  showFilterMessage("Filtros limpos! Exibindo todos os dados.")
}

function showFilterMessage(message) {
  const existingMessage = document.querySelector(".filter-message")
  if (existingMessage) {
    existingMessage.remove()
  }

  const messageDiv = document.createElement("div")
  messageDiv.className = "filter-message"
  messageDiv.textContent = message

  const filtersCard = document.querySelector(".filters-card")
  filtersCard.insertBefore(messageDiv, filtersCard.querySelector(".filter-actions"))

  setTimeout(() => {
    messageDiv.style.opacity = "0"
    setTimeout(() => messageDiv.remove(), 300)
  }, 3000)
}

function updateStatistics() {
  const dataToUse = filteredData.length > 0 ? filteredData : csvData
  const firstNumericColumn = Object.keys(dataToUse[0]).find((key) => !isNaN(dataToUse[0][key]))

  if (!firstNumericColumn) {
    document.getElementById("totalRecords").textContent = dataToUse.length
    document.getElementById("avgValue").textContent = "N/A"
    document.getElementById("maxValue").textContent = "N/A"
    document.getElementById("minValue").textContent = "N/A"
    return
  }

  const values = dataToUse.map((row) => Number.parseFloat(row[firstNumericColumn])).filter((v) => !isNaN(v))

  const total = dataToUse.length
  const avg = (values.reduce((a, b) => a + b, 0) / values.length).toFixed(2)
  const max = Math.max(...values).toFixed(2)
  const min = Math.min(...values).toFixed(2)

  document.getElementById("totalRecords").textContent = total
  document.getElementById("avgValue").textContent = avg
  document.getElementById("maxValue").textContent = max
  document.getElementById("minValue").textContent = min
}

function getSeriesColor(index, total) {
  const hue = (index * 360) / total
  return `hsl(${hue}, 70%, 60%)`
}

function updateCharts() {
  const dataToUse = filteredData.length > 0 ? filteredData : csvData

  if (dataToUse.length === 0) {
    console.log("[v0] Nenhum dado disponível para gráficos")
    return
  }

  const headers = Object.keys(dataToUse[0])
  const numericColumns = headers.filter((header) => {
    return dataToUse.every((row) => !isNaN(row[header]) && row[header] !== "")
  })

  if (numericColumns.length === 0) return

  const labels = dataToUse.map((_, index) => `#${index + 1}`)

  console.log(`[v0] Atualizando gráficos com ${dataToUse.length} pontos e ${numericColumns.length} séries`)

  const lineDatasets = numericColumns
    .filter((column) => visibleLineSeries[column])
    .map((column, index) => {
      const color = getSeriesColor(index, numericColumns.length)
      return {
        label: column,
        data: dataToUse.map((row) => Number.parseFloat(row[column])),
        borderColor: color,
        backgroundColor: color.replace("60%)", "10%)"),
        borderWidth: 2,
        tension: 0.4,
        fill: false,
        pointRadius: dataToUse.length > 50 ? 0 : 3,
        pointHoverRadius: 5,
      }
    })

  // Gráfico de Linha
  const lineCtx = document.getElementById("lineChart").getContext("2d")
  if (lineChart) lineChart.destroy()

  lineChart = new window.Chart(lineCtx, {
    type: "line",
    data: {
      labels: labels,
      datasets: lineDatasets,
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          labels: { color: "#f1f5f9" },
          display: true,
          position: "top",
        },
        tooltip: {
          mode: "index",
          intersect: false,
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { color: "#8892b0" },
          grid: { color: "rgba(255, 255, 255, 0.1)" },
        },
        x: {
          ticks: {
            color: "#8892b0",
            maxTicksLimit: dataToUse.length > 20 ? 10 : dataToUse.length,
          },
          grid: { color: "rgba(255, 255, 255, 0.1)" },
        },
      },
    },
  })

  const areaDatasets = numericColumns
    .filter((column) => visibleAreaSeries[column])
    .map((column, index) => {
      const color = getSeriesColor(index, numericColumns.length)
      return {
        label: column,
        data: dataToUse.map((row) => Number.parseFloat(row[column])),
        borderColor: color,
        backgroundColor: color.replace("60%)", "30%)"),
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: dataToUse.length > 50 ? 0 : 3,
        pointHoverRadius: 5,
      }
    })

  // Gráfico de Área
  const areaCtx = document.getElementById("areaChart").getContext("2d")
  if (areaChart) areaChart.destroy()

  areaChart = new window.Chart(areaCtx, {
    type: "line",
    data: {
      labels: labels,
      datasets: areaDatasets,
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          labels: { color: "#f1f5f9" },
          display: true,
          position: "top",
        },
        tooltip: {
          mode: "index",
          intersect: false,
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { color: "#8892b0" },
          grid: { color: "rgba(255, 255, 255, 0.1)" },
        },
        x: {
          ticks: {
            color: "#8892b0",
            maxTicksLimit: dataToUse.length > 20 ? 10 : dataToUse.length,
          },
          grid: { color: "rgba(255, 255, 255, 0.1)" },
        },
      },
    },
  })

  console.log("[v0] Gráficos atualizados com sucesso")
}

function updateTable(headers) {
  const dataToUse = filteredData.length > 0 ? filteredData : csvData
  const tableHeader = document.getElementById("tableHeader")
  const tableBody = document.getElementById("tableBody")

  // Limpar tabela
  tableHeader.innerHTML = ""
  tableBody.innerHTML = ""

  // Criar cabeçalhos
  headers.forEach((header) => {
    const th = document.createElement("th")
    th.textContent = header
    tableHeader.appendChild(th)
  })

  // Criar linhas
  dataToUse.forEach((row) => {
    const tr = document.createElement("tr")
    headers.forEach((header) => {
      const td = document.createElement("td")
      td.textContent = row[header] || ""
      tr.appendChild(td)
    })
    tableBody.appendChild(tr)
  })
}

// Filtrar tabela
function filterTable() {
  const searchValue = document.getElementById("searchInput").value.toLowerCase()
  const rows = document.querySelectorAll("#tableBody tr")

  rows.forEach((row) => {
    const text = row.textContent.toLowerCase()
    row.style.display = text.includes(searchValue) ? "" : "none"
  })
}

// Ordenar tabela
function sortTable() {
  const sortValue = document.getElementById("sortSelect").value
  if (!sortValue) return

  const dataToUse = filteredData.length > 0 ? filteredData : csvData
  const firstNumericColumn = Object.keys(dataToUse[0]).find((key) => !isNaN(dataToUse[0][key]))
  if (!firstNumericColumn) return

  filteredData.sort((a, b) => {
    const valA = Number.parseFloat(a[firstNumericColumn])
    const valB = Number.parseFloat(b[firstNumericColumn])
    return sortValue === "asc" ? valA - valB : valB - valA
  })

  const headers = Object.keys(dataToUse[0])
  updateTable(headers)
  updateCharts()
}

// Mostrar/ocultar loading
function showLoading(show) {
  const overlay = document.getElementById("loadingOverlay")
  overlay.style.display = show ? "flex" : "none"
}

// Função para gerar cartões de estatísticas dinâmicas
function generateDynamicStats(headers) {
  const dataToUse = filteredData.length > 0 ? filteredData : csvData
  const dynamicStatsGrid = document.getElementById("dynamicStatsGrid")
  const dynamicStatsContainer = document.getElementById("dynamicStatsContainer")

  if (dataToUse.length === 0) {
    dynamicStatsContainer.style.display = "none"
    return
  }

  dynamicStatsContainer.style.display = "block"
  dynamicStatsGrid.innerHTML = ""

  const specificFields = [
    {
      name: "Tentativas",
      icon: "fa-redo",
      color: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
      type: "numeric",
    },
    {
      name: "Índice de Facilidade",
      icon: "fa-smile",
      color: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
      type: "numeric",
    },
    {
      name: "Desvio Padrão",
      icon: "fa-chart-bar",
      color: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
      type: "numeric",
    },
    {
      name: "Pontuação Aleatória",
      icon: "fa-dice",
      color: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
      type: "numeric",
    },
    {
      name: "Peso Planejado",
      icon: "fa-balance-scale",
      color: "linear-gradient(135deg, #fa709a 0%, #fee140 100%)",
      type: "numeric",
    },
    {
      name: "Peso Efetivo",
      icon: "fa-weight",
      color: "linear-gradient(135deg, #30cfd0 0%, #330867 100%)",
      type: "numeric",
    },
    {
      name: "Índice de Discriminação",
      icon: "fa-filter",
      color: "linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)",
      type: "numeric",
    },
    {
      name: "Eficiência de Discriminação",
      icon: "fa-percentage",
      color: "linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)",
      type: "numeric",
    },
    {
      name: "Objeto de Conhecimento",
      icon: "fa-book",
      color: "linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)",
      type: "categorical",
    },
    {
      name: "Unidade de Competência",
      icon: "fa-graduation-cap",
      color: "linear-gradient(135deg, #ff6e7f 0%, #bfe9ff 100%)",
      type: "categorical",
    },
    {
      name: "Elemento de Competência",
      icon: "fa-puzzle-piece",
      color: "linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%)",
      type: "categorical",
    },
  ]

  const statsCards = []

  specificFields.forEach((field) => {
    // Verificar se o campo existe nos headers
    if (!headers.includes(field.name)) return

    const values = dataToUse.map((row) => row[field.name]).filter((v) => v !== "" && v !== undefined)

    if (values.length === 0) return

    if (field.type === "numeric") {
      // Estatísticas para campos numéricos
      const numericValues = values.map((v) => Number.parseFloat(v)).filter((v) => !isNaN(v))

      if (numericValues.length === 0) return

      const sum = numericValues.reduce((a, b) => a + b, 0)
      const avg = sum / numericValues.length
      const max = Math.max(...numericValues)
      const min = Math.min(...numericValues)

      statsCards.push({
        icon: field.icon,
        value: avg.toFixed(2),
        label: `Média - ${field.name}`,
        color: field.color,
        subtitle: `Min: ${min.toFixed(2)} | Max: ${max.toFixed(2)}`,
      })
    } else {
      // Estatísticas para campos categóricos
      const uniqueValues = [...new Set(values)]
      const frequency = values.reduce((acc, val) => {
        acc[val] = (acc[val] || 0) + 1
        return acc
      }, {})
      const mostCommonValue = Object.keys(frequency).reduce((a, b) => (frequency[a] > frequency[b] ? a : b))
      const mostCommonCount = frequency[mostCommonValue]

      statsCards.push({
        icon: field.icon,
        value: uniqueValues.length,
        label: `Valores Únicos - ${field.name}`,
        color: field.color,
        subtitle: `Mais comum: ${mostCommonValue} (${mostCommonCount}x)`,
      })
    }
  })

  // Renderizar os cards
  statsCards.forEach((card) => {
    const statCard = document.createElement("div")
    statCard.className = "stat-card dynamic-stat-card fade-in"

    statCard.innerHTML = `
      <div class="stat-icon" style="background: ${card.color}">
        <i class="fas ${card.icon}"></i>
      </div>
      <div class="stat-content">
        <h3>${card.value}</h3>
        <p>${card.label}</p>
        ${card.subtitle ? `<small class="stat-subtitle">${card.subtitle}</small>` : ""}
      </div>
    `

    dynamicStatsGrid.appendChild(statCard)
  })
}

// Função para alternar a visibilidade dos cartões de estatísticas dinâmicas
function toggleDynamicStats() {
  const dynamicStatsGrid = document.getElementById("dynamicStatsGrid")
  const toggleIcon = document.getElementById("toggleStatsIcon")
  const toggleText = document.getElementById("toggleStatsText")

  if (dynamicStatsGrid.style.display === "none") {
    dynamicStatsGrid.style.display = "grid"
    toggleIcon.className = "fas fa-eye-slash"
    toggleText.textContent = "Ocultar Estatísticas"
  } else {
    dynamicStatsGrid.style.display = "none"
    toggleIcon.className = "fas fa-eye"
    toggleText.textContent = "Mostrar Estatísticas"
  }
}

/* ===========================
   Nova função: exportar/printar relatórios (gráficos + tabela) para PDF
   =========================== */
async function printReportsPdf() {
  const printBtn = document.getElementById('printReportBtn')
  if (!printBtn) return

  // Garantir que existam elementos para exportar
  const lineCanvas = document.getElementById('lineChart')
  const areaCanvas = document.getElementById('areaChart')
  const table = document.getElementById('dataTable')

  if (!lineCanvas && !areaCanvas && !table) {
    alert('Não há conteúdo para imprimir. Carregue um CSV para gerar gráficos e tabela.')
    return
  }

  try {
    // Desabilitar botão para evitar duplicidade e mostrar loading
    printBtn.disabled = true
    printBtn.style.opacity = '0.6'
    showLoading(true)

    // Criar container temporário com fundo branco (melhor para PDF)
    const tmp = document.createElement('div')
    tmp.id = 'pdfExportContainer'
    tmp.style.padding = '18px'
    tmp.style.background = '#ffffff'
    tmp.style.color = '#000000'
    tmp.style.maxWidth = '1100px'
    tmp.style.margin = '0 auto'
    tmp.style.fontFamily = 'Arial, Helvetica, sans-serif'
    tmp.style.fontSize = '12px'
    tmp.style.lineHeight = '1.3'

    // Título
    const title = document.createElement('h2')
    title.textContent = 'Relatório de Gráficos - EduReports'
    title.style.textAlign = 'center'
    title.style.marginBottom = '12px'
    tmp.appendChild(title)

    // Data/hora
    const dateSpan = document.createElement('div')
    const now = new Date()
    dateSpan.textContent = `Gerado em: ${now.toLocaleString()}`
    dateSpan.style.textAlign = 'center'
    dateSpan.style.marginBottom = '16px'
    dateSpan.style.color = '#333'
    tmp.appendChild(dateSpan)

    // Função auxiliar para adicionar canvas como imagem
    const addCanvasAsImage = (canvasEl, captionText) => {
      try {
        const url = canvasEl.toDataURL('image/png', 1.0)
        const wrapper = document.createElement('div')
        wrapper.style.marginBottom = '18px'
        const caption = document.createElement('div')
        caption.textContent = captionText || ''
        caption.style.fontWeight = '700'
        caption.style.marginBottom = '8px'
        caption.style.color = '#222'
        wrapper.appendChild(caption)
        const img = document.createElement('img')
        img.src = url
        img.style.maxWidth = '100%'
        img.style.display = 'block'
        img.style.border = '1px solid #ddd'
        img.style.padding = '6px'
        img.style.background = '#fff'
        wrapper.appendChild(img)
        tmp.appendChild(wrapper)
      } catch (err) {
        console.warn('Erro ao converter canvas para imagem', err)
      }
    }

    if (lineCanvas) {
      addCanvasAsImage(lineCanvas, 'Gráfico de Linha - Tendência')
    }
    if (areaCanvas) {
      addCanvasAsImage(areaCanvas, 'Gráfico de Área')
    }

    // Adicionar uma quebra visual antes da tabela
    if (table) {
      const tblCaption = document.createElement('div')
      tblCaption.textContent = 'Tabela de Dados'
      tblCaption.style.fontWeight = '700'
      tblCaption.style.margin = '12px 0'
      tblCaption.style.color = '#222'
      tmp.appendChild(tblCaption)

      // Clonar a tabela existente para preservar a original
      const tableClone = table.cloneNode(true)
      // Remover elementos interativos se houver
      tableClone.querySelectorAll('input, button, select').forEach(el => el.remove())

      // Ajustes de estilo para ficar bom no PDF
      tableClone.style.width = '100%'
      tableClone.style.borderCollapse = 'collapse'
      tableClone.querySelectorAll('th').forEach(th => {
        th.style.background = '#f1f1f1'
        th.style.color = '#111'
        th.style.padding = '6px'
        th.style.border = '1px solid #ddd'
      })
      tableClone.querySelectorAll('td').forEach(td => {
        td.style.padding = '6px'
        td.style.border = '1px solid #eee'
        td.style.color = '#111'
      })

      // Encapsular em div para ter margens
      const tableWrapper = document.createElement('div')
      tableWrapper.style.overflowX = 'auto'
      tableWrapper.appendChild(tableClone)
      tmp.appendChild(tableWrapper)
    }

    // Adicionar o container temporário ao body (invisível na tela por background branco e margens centralizadas)
    document.body.appendChild(tmp)

    // Configurações do html2pdf
    const opt = {
      margin:       0.4,
      filename:     'relatorio_graficos.pdf',
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true, logging: false },
      jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
    }

    // Gerar e salvar PDF (aguarda a conclusão)
    await html2pdf().set(opt).from(tmp).save()

    // Remover container temporário
    tmp.remove()

  } catch (error) {
    console.error('Erro ao gerar PDF:', error)
    alert('Ocorreu um erro ao gerar o PDF. Veja o console para mais detalhes.')
  } finally {
    // Reabilitar botão e esconder loading
    const printBtnFinal = document.getElementById('printReportBtn')
    if (printBtnFinal) {
      printBtnFinal.disabled = false
      printBtnFinal.style.opacity = '1'
    }
    showLoading(false)
  }
}

/* ===========================
   Fim das adições — resto do script já existente continua
   =========================== */

// (o restante do script já definido acima permanece conforme estava)